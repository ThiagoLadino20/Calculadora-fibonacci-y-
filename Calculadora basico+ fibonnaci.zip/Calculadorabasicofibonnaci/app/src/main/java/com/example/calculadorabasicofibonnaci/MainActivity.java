package com.example.calculadorabasicofibonnaci;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btn_suma;
    private Button btn_resta;
    private Button btn_division;
    private Button btn_multiplicacion;
    private Button btn_factorial;
    private Button btn_fibonacci;

    private TextView text_respuesta;

    private EditText edit_numero_uno;
    private EditText edit_numero_dos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text_respuesta = findViewById(R.id.respuesta);
        edit_numero_uno = findViewById(R.id.numero1);
        edit_numero_dos = findViewById(R.id.numero2);

        btn_suma = findViewById(R.id.button_suma);
        btn_suma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_respuesta.setText(String.valueOf(suma(
                        Integer.parseInt(edit_numero_uno.getText().toString()),
                        Integer.parseInt(edit_numero_dos.getText().toString()))));
            }
        });

        btn_resta = findViewById(R.id.button_resta);
        btn_resta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_respuesta.setText(String.valueOf(resta(
                        Integer.parseInt(edit_numero_uno.getText().toString()),
                        Integer.parseInt(edit_numero_dos.getText().toString()))));
            }
        });

        btn_division = findViewById(R.id.button_division);
        btn_division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_respuesta.setText(String.valueOf(division(
                        Integer.parseInt(edit_numero_uno.getText().toString()),
                        Integer.parseInt(edit_numero_dos.getText().toString()))));
            }
        });

        btn_multiplicacion = findViewById(R.id.button_multiplicacion);
        btn_multiplicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_respuesta.setText(String.valueOf(multiplicacion(
                        Integer.parseInt(edit_numero_uno.getText().toString()),
                        Integer.parseInt(edit_numero_dos.getText().toString()))));
            }
        });

        btn_factorial = findViewById(R.id.button_factorial);
        btn_factorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_respuesta.setText(String.valueOf(factorial(
                        Integer.parseInt(edit_numero_uno.getText().toString()))));
            }
        });

        btn_fibonacci = findViewById(R.id.button_fibonacci);
        btn_fibonacci.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_respuesta.setText(String.valueOf(fibonacci(
                        Integer.parseInt(edit_numero_uno.getText().toString()))));
            }
        });
    }

    public double suma(int a, int b) {
        return a + b;
    }

    public double resta(int a, int b) {
        return a - b;
    }

    public double multiplicacion(int a, int b) {
        return a * b;
    }

    public double division(int a, int b) {
        if (b != 0) {
            return (double) a / b;
        } else {
            // Manejar división por cero como desees
            return Double.NaN; // Devolver NaN (Not a Number) como ejemplo
        }
    }

    public int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }

    public int fibonacci(int n) {
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            int a = 0;
            int b = 1;
            int result = 0;

            for (int i = 2; i <= n; i++) {
                result = a + b;
                a = b;
                b = result;
            }

            return result;
        }
    }
}
